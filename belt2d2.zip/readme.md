# Steps to deploy this application

1. Git clone the repository
2. Navigate to the path where you have pom.xml
3. Run "mvn clean"
4. Run "mvn compile"
5. Run "mvn package"
6. Publish the test case report
7. Java application is created as a jar application in target folder
8. Deploy this application on AWS beanstalk application
9. Access the application. Login credentials -- Username - admin1, Password - secret1
